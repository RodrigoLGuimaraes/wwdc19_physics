//: A SpriteKit based Playground

let script = Script.defaultScript

Launcher().start(with: script)
