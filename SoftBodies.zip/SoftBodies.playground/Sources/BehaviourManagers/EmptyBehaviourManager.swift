import Foundation
import SpriteKit

public class EmptyBehaviourManager: BehaviourManager {
    public func performBehavior(on behavers: [SKSpriteNode], given stimulusLocation: CGPoint) {}
}

