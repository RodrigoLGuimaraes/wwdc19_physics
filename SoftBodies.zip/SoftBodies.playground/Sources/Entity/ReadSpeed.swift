import Foundation

enum ReadSpeed: Int { //in small words per second
    case slow = 1
    case regular = 3
    case fast = 5
}
