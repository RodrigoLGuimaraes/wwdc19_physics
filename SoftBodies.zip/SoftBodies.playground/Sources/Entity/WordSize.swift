import Foundation

enum WordSize: Int {
    case small = 1
    case regular = 2
    case big = 3
}
